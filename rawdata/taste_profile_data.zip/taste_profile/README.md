This folder contains three files:
- `interactions.csv`: a CSV of every interaction in the taste profile subset, with each row containing a user ID, track ID, and listen count
- `tracks.txt`: a list of every unique track found in `interactions.csv`, separated by a new line (\n)
- `users.txt`: a list of every unique user found in `interactions.csv`, separated by a new line (\n)
